const fs = require('fs');
const path = require('path');
const archiver = require('archiver');

function nowName() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2,'0');
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}_${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}`;
}

const root = path.join(__dirname, '..');
const backupsDir = path.join(root, 'backups');
fs.mkdirSync(backupsDir, { recursive: true });

const outPath = path.join(backupsDir, `backup_${nowName()}.zip`);
const output = fs.createWriteStream(outPath);
const archive = archiver('zip', { zlib: { level: 9 } });

archive.pipe(output);
archive.directory(path.join(root, 'data'), 'data');
archive.directory(path.join(root, 'uploads'), 'uploads');
archive.file(path.join(root, '.env'), { name: '.env', stats: fs.existsSync(path.join(root, '.env')) ? fs.statSync(path.join(root, '.env')) : undefined });

archive.finalize();

output.on('close', () => {
  console.log('✅ Backup hazır:', outPath, `(${archive.pointer()} bytes)`);
});
