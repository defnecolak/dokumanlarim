function copyText(id){
  const el = document.getElementById(id);
  if(!el) return;
  const txt = el.value || el.textContent || '';
  navigator.clipboard.writeText(txt).then(()=>{
    toast('Kopyalandı');
  }).catch(()=>{});
}
function toast(msg){
  const t = document.createElement('div');
  t.className = 'flash ok';
  t.style.position='fixed'; t.style.bottom='20px'; t.style.left='50%'; t.style.transform='translateX(-50%)';
  t.style.zIndex='9999'; t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(()=>t.remove(), 1800);
}
